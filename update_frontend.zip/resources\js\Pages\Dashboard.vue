<script setup>
import { ref, computed, reactive, watch, onMounted, onUnmounted, nextTick } from 'vue';
import { usePage, Link, router, Head } from '@inertiajs/vue3';
import {
    Waves, User, Wallet, Trash2, Edit2, LogIn, LogOut, Plus, X, Search, ChevronDown,
    CheckCircle2, AlertTriangle,
    Menu, Printer, Download, Settings, Lock, QrCode, TrendingUp, TrendingDown, Scale, Home, Banknote,
    MapPin, MessageCircle, Circle, History, Calendar, Calculator, Package
} from 'lucide-vue-next';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';

// ✅ FIX #1: defineProps HARUS paling atas sebelum computed lain
const props = defineProps({
    wargas:   { type: Array,  default: () => [] },
    users:    { type: Array,  default: () => [] },
    expenses: { type: Array,  default: () => [] },
    incomes:  { type: Array,  default: () => [] },
    inventaris: { type: Array,  default: () => [] },
    user:     { type: Object, default: null }
});

// ============================================================
// CONSTANTS (letakkan di atas karena dipakai banyak fungsi)
// ============================================================
const MONTH_KEYS  = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const MONTH_NAMES = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const MONTHS      = MONTH_KEYS.map((key, index) => ({ key, label: MONTH_NAMES[index] }));


// ============================================================
// STATE
// ============================================================
const page        = usePage();
const currentUser = computed(() => props.user || page.props.auth?.user);

const activeTab      = ref('dashboard');
const activeCategory = ref('air');

const residents   = computed(() => props.wargas   || []);
const adminList   = computed(() => props.users    || []);  // ✅ FIX: pakai props bukan page.props
const expenseList = computed(() => props.expenses || []);
const incomeList  = computed(() => props.incomes  || []);

const showAmountOptions = ref(null);
const isMobileMenuOpen  = ref(false);


// State Tahun & Keuangan
const currentYear            = new Date().getFullYear();
const paymentYear            = ref(currentYear);
const selectedFinancialYear  = ref(currentYear);
const selectedMonthKey       = ref(MONTH_KEYS[new Date().getMonth()]);
const financeViewMode        = ref('monthly');
const availableYears         = [2025, 2026, 2027];

// State Accordion
const openBlocks  = reactive({});
const toggleBlock = (blockName) => { openBlocks[blockName] = !openBlocks[blockName]; };

// ============================================================
// TABS
// ============================================================
const allTabs = [
    { id: 'dashboard', label: 'Data Warga',  icon: Home     },
    { id: 'finance',   label: 'Keuangan',    icon: Wallet   },
    { id: 'inventaris', label: 'Inventaris', icon: Package },
    { id: 'settings',  label: 'Pengaturan',  icon: Settings }
];

// ✅ Hapus kedua komentar itu
const visibleTabs = computed(() =>
    allTabs.filter(tab => {
        if (!currentUser.value && tab.id === 'settings') return false;
        return true;
    })
);

// ============================================================
// KEYBOARD HANDLER
// ============================================================
const handleKeydown = (e) => {
    if (e.key === 'Escape') {
        showResidentModal.value  = false;
        showPaymentModal.value   = false;
        showAdminModal.value     = false;
        showQrisModal.value      = false;
        showExpenseModal.value   = false;
        showIncomeModal.value    = false;
        showLetterModal.value    = false;
        showInventarisModal.value = false;
        showAmountOptions.value  = null;
        isMobileMenuOpen.value   = false;
    }
};

onMounted(() => {
    document.addEventListener('keydown', handleKeydown);
    // ✅ FIX #5: Hapus auto-popup QRIS — sangat mengganggu UX
    // showQrisModal.value = true;
});
onUnmounted(() => document.removeEventListener('keydown', handleKeydown));

// ============================================================
// HELPER FUNCTIONS
// ============================================================

// ✅ FIX: Aman dari bug timezone
const parseDateSafe = (dateString) => {
    if (!dateString) return { year: new Date().getFullYear(), monthIndex: new Date().getMonth() };
    try {
        const datePart = String(dateString).split('T')[0].split(' ')[0];
        const [y, m] = datePart.split('-');
        return { year: parseInt(y), monthIndex: parseInt(m) - 1 };
    } catch {
        return { year: new Date().getFullYear(), monthIndex: new Date().getMonth() };
    }
};

const getHistoryKey = (monthKey, year) =>
    year === 2025 ? monthKey : `${monthKey}_${year}`;

// ✅ FIX #6: Hapus duplikat key 'may', bersihkan alias tidak terpakai
function isNewTarifPeriod(monthKey, year) {
    const idx = MONTH_KEYS.indexOf(monthKey.toLowerCase().substring(0, 3));
    if (idx === -1) return false;
    return year > 2026 || (year === 2026 && idx >= 2);
}

// ✅ FIX #4: Pakai Number() + || 0 supaya tidak NaN
const safeInt = (val) => Number(val) || 0;

const getPaymentDetail = (amount, monthIndex, year) => {
    const idx = typeof monthIndex === 'string' ? MONTH_KEYS.indexOf(monthIndex) : monthIndex;
    const isPaketStarted = year > 2026 || (year === 2026 && idx >= 2);

    if (!isPaketStarted) return { air: amount, sampah: 0, kas: 0 };

    switch (amount) {
        case 100000: return { air: 50000, sampah: 30000, kas: 20000 };
        case  70000: return { air: 50000, sampah:     0, kas: 20000 };
        case  50000: return { air: 20000, sampah: 10000, kas: 20000 };
        case  50001: return { air: 50000, sampah:     0, kas:     0 };
        case  50002: return { air:     0, sampah: 30000, kas: 20000 };
        case  30000: return { air:     0, sampah: 10000, kas: 20000 };
        case  30001: return { air:     0, sampah: 30000, kas:     0 };
        case  20000: return { air: 20000, sampah:     0, kas:     0 };
        case  10000: return { air:     0, sampah: 10000, kas:     0 };
        default:     return { air: amount, sampah: 0, kas: 0 };
    }
};

const getPaymentAmount = (resident, monthKey, year) => {
    const monthIdx = MONTH_KEYS.indexOf(monthKey);
    const key      = getHistoryKey(monthKey, year);
    const val      = resident?.payment_history?.[key];

    if (val) {
        if (typeof val === 'number') return val;
        if (val === true) return safeInt(resident.tarif || 20000);
    }

    if (year === 2026 && (monthIdx === 0 || monthIdx === 1)) {
        const join         = parseDateSafe(resident.join_date);
        if (join.year > 2026 || (join.year === 2026 && join.monthIndex >= 2)) return 0;
    }

    return 0;
};

const formatRupiah = (val) =>
    new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(val || 0);

const formatDate = (dateString) =>
    new Date(dateString).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' });

// ============================================================
// FILTER & GROUPING
// ============================================================
const searchQuery = ref('');

const filteredResidents = computed(() => {
    let data = residents.value.filter(r => r.is_active !== false);
    if (searchQuery.value) {
        const q = searchQuery.value.toLowerCase();
        data = data.filter(r =>
            r.nama?.toLowerCase().includes(q) ||
            r.blok?.toLowerCase().includes(q)  ||
            r.nomor?.toString().includes(q)
        );
    }
    return data.sort((a, b) => {
        const bA = (a.blok || '').replace(/\s+/g, '').toUpperCase();
        const bB = (b.blok || '').replace(/\s+/g, '').toUpperCase();
        return bA === bB ? parseInt(a.nomor) - parseInt(b.nomor) : bA.localeCompare(bB);
    });
});

const groupedResidents = computed(() => {
    const groups = {};
    filteredResidents.value.forEach(r => {
        const key = (r.blok || 'LAINNYA').toString()
            .replace(/^blok\s*/i, '').replace(/\s+/g, '').toUpperCase();
        if (!groups[key]) groups[key] = [];
        groups[key].push(r);
    });
    return Object.fromEntries(Object.keys(groups).sort().map(k => [k, groups[k]]));
});

// ============================================================
// FINANCIAL COMPUTED
// ============================================================

// ✅ FIX #7: Filter tanggal pakai parseDateSafe, bukan .includes()
const detailedIncomeList = computed(() => {
    const year       = selectedFinancialYear.value;
    const monthKey   = selectedMonthKey.value;
    const monthIndex = MONTH_KEYS.indexOf(monthKey);
    const historyKey = getHistoryKey(monthKey, year);
    const cat        = activeCategory.value.toLowerCase();

    const wargaIncomes = (props.wargas || []).map(resident => {
        const val = resident.payment_history?.[historyKey];
        if (!val) return null;
        const totalAmount    = (typeof val === 'number') ? val : safeInt(resident.tarif);
        const detail         = getPaymentDetail(totalAmount, monthIndex, year);
        const categoryAmount = detail[cat] || 0;
        if (categoryAmount <= 0) return null;
        return {
            id: resident.id, type: 'warga',
            keterangan: `${resident.nama || '-'} (${resident.blok || '-'})`,
            info: 'Rutin', amount: categoryAmount, date: resident.updated_at
        };
    }).filter(Boolean);

    const manualIncomes = (props.incomes || []).filter(inc => {
        // ✅ FIX: Gunakan parseDateSafe bukan .includes()
        const { year: y, monthIndex: mIdx } = parseDateSafe(inc.date);
        return y === year && MONTH_KEYS[mIdx] === monthKey && inc.category?.toLowerCase() === cat;
    }).map(inc => ({
        id: inc.id, type: 'manual',
        keterangan: inc.description, info: inc.date,
        amount: safeInt(inc.amount), date: inc.date
    }));

    return [...wargaIncomes, ...manualIncomes]
        .sort((a, b) => new Date(b.date) - new Date(a.date));
});

// ✅ SESUDAH - konsisten dengan runningBalanceByCategory
const currentMonthIncomeByCategory = computed(() => {
    const year       = selectedFinancialYear.value;
    const monthKey   = selectedMonthKey.value;
    const monthIndex = MONTH_KEYS.indexOf(monthKey);
    const historyKey = getHistoryKey(monthKey, year);
    const isNew      = isNewTarifPeriod(monthKey, year); // ← tambah ini
    let   total      = 0;

    residents.value.forEach(r => {
        const val = r.payment_history?.[historyKey];
        if (!val) return;
        const amount = (typeof val === 'number') ? val : safeInt(r.tarif);
        const detail = getPaymentDetail(amount, monthIndex, year);
        
        // Periode lama hanya masuk 'air'
        if (isNew) {
            total += detail[activeCategory.value] || 0;
        } else if (activeCategory.value === 'air') {
            total += detail.air || 0;
        }
    });

    incomeList.value.forEach(inc => {
        const { year: y, monthIndex: mIdx } = parseDateSafe(inc.date);
        if (y !== year || MONTH_KEYS[mIdx] !== monthKey) return;
        const incCat = inc.category?.toLowerCase();
        if (isNew ? incCat === activeCategory.value : activeCategory.value === 'air' && incCat === 'air') {
            total += safeInt(inc.amount);
        }
    });

    return total;
});

const currentMonthExpenseByCategory = computed(() => {
    if (!expenseList.value) return 0;
    return expenseList.value
        .filter(e => {
            const { year, monthIndex } = parseDateSafe(e.date);
            return MONTH_KEYS[monthIndex] === selectedMonthKey.value &&
                   year === selectedFinancialYear.value &&
                   e.category?.toLowerCase() === activeCategory.value.toLowerCase();
        })
        .reduce((sum, e) => sum + safeInt(e.amount), 0); // ✅ FIX #4
});

const currentCategoryNet = computed(() =>
    currentMonthIncomeByCategory.value - currentMonthExpenseByCategory.value
);

// Alias agar template tidak perlu diubah
const currentCategoryExpense = currentMonthExpenseByCategory;

const runningBalanceByCategory = computed(() => {
    const targetYear     = selectedFinancialYear.value;
    const targetMonthIdx = MONTH_KEYS.indexOf(selectedMonthKey.value);
    const activeCat      = activeCategory.value.toLowerCase();

    let income  = 0;
    let expense = 0;

    for (const year of availableYears) {
        if (year > targetYear) break;
        for (let mIdx = 0; mIdx < 12; mIdx++) {
            if (year === targetYear && mIdx > targetMonthIdx) break;

            const mKey       = MONTH_KEYS[mIdx];
            const historyKey = getHistoryKey(mKey, year);
            const isNew      = isNewTarifPeriod(mKey, year);

            residents.value.forEach(r => {
                const val = r.payment_history?.[historyKey];
                if (!val) return;
                const amount = (typeof val === 'number') ? val : safeInt(r.tarif || 20000);
                const detail = getPaymentDetail(amount, mIdx, year);
                if (isNew) {
                    income += detail[activeCat] || 0;
                } else if (activeCat === 'air') {
                    income += detail.air || 0;
                }
            });

            incomeList.value.forEach(inc => {
                const { year: y, monthIndex: m } = parseDateSafe(inc.date);
                if (y !== year || m !== mIdx) return;
                const cat = (inc.category || 'air').toLowerCase();
                if (isNew ? cat === activeCat : activeCat === 'air' && cat === 'air') {
                    income += safeInt(inc.amount);
                }
            });

            expenseList.value.forEach(ex => {
                const { year: y, monthIndex: m } = parseDateSafe(ex.date);
                if (y !== year || m !== mIdx) return;
                const cat = (ex.category || 'air').toLowerCase();
                if (isNew ? cat === activeCat : activeCat === 'air' && cat === 'air') {
                    expense += safeInt(ex.amount);
                }
            });
        }
    }

    // Trik: Menambahkan saldo awal/penyesuaian dari tahun 1999 yang tidak muncul di Laporan normal
    incomeList.value.forEach(inc => {
        const { year: y } = parseDateSafe(inc.date);
        if (y === 1999 && (inc.category || 'air').toLowerCase() === activeCat) {
            income += safeInt(inc.amount);
        }
    });

    return income - expense;
});

const yearlyReportData = computed(() => {
    const year = selectedFinancialYear.value;
    return MONTH_KEYS.map((mKey, index) => {
        let resIncome = 0;
        residents.value.forEach(r => {
            const val = r.payment_history?.[getHistoryKey(mKey, year)];
            if (typeof val === 'number') resIncome += val;
            else if (val === true) resIncome += safeInt(r.tarif || 20000);
        });

        const manIncome = incomeList.value
            .filter(inc => { const { year: y, monthIndex: m } = parseDateSafe(inc.date); return y === year && m === index; })
            .reduce((s, inc) => s + safeInt(inc.amount), 0);

        const exp = expenseList.value
            .filter(ex => { const { year: y, monthIndex: m } = parseDateSafe(ex.date); return y === year && m === index; })
            .reduce((s, ex) => s + safeInt(ex.amount), 0);

        return { monthName: MONTH_NAMES[index], income: resIncome + manIncome, expense: exp, surplus: (resIncome + manIncome) - exp };
    });
});

const yearlyTotalIncome  = computed(() => yearlyReportData.value.reduce((s, r) => s + r.income,  0));
const yearlyTotalExpense = computed(() => yearlyReportData.value.reduce((s, r) => s + r.expense, 0));


const filteredExpensesByCategory = computed(() => {
    const cat      = activeCategory.value.toLowerCase();
    const monthKey = selectedMonthKey.value;
    const year     = selectedFinancialYear.value;
    return (expenseList.value || []).filter(e => {
        const { year: y, monthIndex } = parseDateSafe(e.date);
        return y === year && MONTH_KEYS[monthIndex] === monthKey && e.category?.toLowerCase() === cat;
    });
});

// ============================================================
// DEBT / TUNGGAKAN
// ============================================================
const debtReportMonthKey = ref(MONTH_KEYS[new Date().getMonth()]);

const overdueResidents = computed(() => {
    const year       = selectedFinancialYear.value;
    const historyKey = getHistoryKey(debtReportMonthKey.value, year);
    return residents.value
        .filter(r => r.is_active !== false)
        .filter(r => {
            const val = r.payment_history?.[historyKey];
            return !((typeof val === 'number' && val > 0) || val === true);
        })
        .sort((a, b) => {
            const bA = (a.blok || '').replace(/\s+/g, '').toUpperCase();
            const bB = (b.blok || '').replace(/\s+/g, '').toUpperCase();
            return bA === bB ? parseInt(a.nomor || 0) - parseInt(b.nomor || 0) : bA.localeCompare(bB);
        });
});

const overdueResidentsWithCount = computed(() => {
    const year          = selectedFinancialYear.value;
    const currentMonthIdx = MONTH_KEYS.indexOf(debtReportMonthKey.value);
    return residents.value
        .filter(r => r.is_active !== false)
        .map(r => {
    let unpaidCount = 0;
    for (let i = 0; i <= currentMonthIdx; i++) {
        const mKey = MONTH_KEYS[i];
        // ✅ Skip bulan yang belum saatnya (lebih dari bulan sekarang di tahun ini)
        const now = new Date();
        if (year === now.getFullYear() && i > now.getMonth()) continue;
        
        const val = r.payment_history?.[getHistoryKey(mKey, year)];
        if (!((typeof val === 'number' && val > 0) || val === true)) unpaidCount++;
    }
    return { ...r, unpaidCount };
})
        .filter(r => r.unpaidCount > 0)
        .sort((a, b) => {
            const bA = (a.blok || '').replace(/\s+/g, '').toUpperCase();
            const bB = (b.blok || '').replace(/\s+/g, '').toUpperCase();
            return bA === bB ? parseInt(a.nomor || 0) - parseInt(b.nomor || 0) : bA.localeCompare(bB);
        });
});

// ============================================================
// MODAL STATE & FORMS
// ============================================================
const showResidentModal = ref(false);
const showPaymentModal  = ref(false);
const showAdminModal    = ref(false);
const showQrisModal     = ref(false);
const showExpenseModal  = ref(false);
const showIncomeModal   = ref(false);
const showLetterModal   = ref(false);
const showSaldoModal    = ref(false);

const selectedResident          = ref(null);
const selectedResidentForLetter = ref(null);
const isEditing                 = ref(false);
const editId                    = ref(null);

const formResident = reactive({ nama: '', blok: '', nomor: '', telepon: '', tarif: 20000, is_active: true });
const formAdmin    = reactive({ name: '', email: '', password: '', password_confirmation: '' });
const formExpense  = reactive({ description: '', amount: '', date: new Date().toISOString().split('T')[0], category: 'air' });
const formIncome   = reactive({ description: '', amount: '', date: new Date().toISOString().split('T')[0], category: 'air' });
const formSaldo    = reactive({ id: null, amount: '' });

const isAdminEditing   = ref(false); const editAdminId   = ref(null);
const isExpenseEditing = ref(false); const editExpenseId = ref(null);
const isIncomeEditing  = ref(false); const editIncomeId  = ref(null);


// ============================================================
// ACTIONS
// ============================================================
const deleteItem = (type, id) => {
    if (!confirm('Hapus data ini?')) return;
    const urls = {
        resident: `/wargas/delete/${id}`,
        admin:    `/users/delete/${id}`,
        expense:  `/expenses/delete/${id}`,
        income:   `/incomes/delete/${id}`
    };
    router.post(urls[type], {}, {
        preserveScroll: true,
        onSuccess: () => alert('Data berhasil dihapus'),
        onError:   () => alert('Gagal menghapus data')
    });
};

const openResidentModal = (resident = null) => {
    if (resident) {
        isEditing.value = true; editId.value = resident.id;
        formResident.nama      = resident.nama;
        formResident.blok      = resident.blok;
        formResident.nomor     = resident.nomor     || '';
        formResident.telepon   = resident.telepon   || '';
        formResident.tarif     = [20000, 50000].includes(resident.tarif) ? resident.tarif : 20000;
        formResident.is_active = resident.is_active !== false;
    } else {
        isEditing.value = false; editId.value = null;
        Object.assign(formResident, { nama: '', blok: '', nomor: '', telepon: '', tarif: 20000, is_active: true });
    }
    showResidentModal.value = true;
};

const submitResident = () => {
    const url = isEditing.value ? `/wargas/update/${editId.value}` : '/wargas/store';
    router.post(url, formResident, {
        preserveScroll: true,
        onSuccess: () => { showResidentModal.value = false; },
        onError:   (e) => { console.error(e); alert('Gagal menyimpan data.'); }
    });
};

// ✅ FIX #10: Gabung editIncome ke dalam openIncomeModal
const openIncomeModal = (income = null) => {
    if (income) {
        isIncomeEditing.value = true; editIncomeId.value = income.id;
        formIncome.description = income.description;
        formIncome.amount      = income.amount;
        formIncome.date        = income.date;
        formIncome.category    = income.category || activeCategory.value.toLowerCase();
    } else {
        isIncomeEditing.value = false; editIncomeId.value = null;
        Object.assign(formIncome, { description: '', amount: '', date: new Date().toISOString().split('T')[0], category: activeCategory.value.toLowerCase() });
    }
    showIncomeModal.value = true;
};

const submitIncome = () => {
    if (!formIncome.description) return alert('Keterangan wajib diisi.');
    if (!formIncome.amount || safeInt(formIncome.amount) <= 0) return alert('Nominal harus lebih dari 0.');
    const url = isIncomeEditing.value ? `/incomes/update/${editIncomeId.value}` : '/incomes/store';
    router.post(url, formIncome, {
        preserveScroll: true,
        onSuccess: () => { showIncomeModal.value = false; },
        onError:   () => alert('Gagal menyimpan pemasukan.')
    });
};

const deleteIncome = (id) => {
    if (!confirm('Hapus pemasukan ini?')) return;
    router.post(`/incomes/delete/${id}`, {}, {
        preserveScroll: true,
        onSuccess: () => alert('Pemasukan dihapus'),
        onError:   () => alert('Gagal menghapus')
    });
};

const openSaldoModal = () => {
    const existing = incomeList.value.find(inc => {
        const { year: y } = parseDateSafe(inc.date);
        return y === 1999 && (inc.category || 'air').toLowerCase() === activeCategory.value;
    });
    if (existing) {
        formSaldo.id = existing.id;
        formSaldo.amount = existing.amount;
    } else {
        formSaldo.id = null;
        formSaldo.amount = '';
    }
    showSaldoModal.value = true;
};

const submitSaldo = () => {
    const amt = formSaldo.amount === '' ? 0 : Number(formSaldo.amount);
    const url = formSaldo.id ? `/incomes/update/${formSaldo.id}` : `/incomes/store`;
    router.post(url, {
        description: `[ADJUSTMENT] Saldo Awal ${activeCategory.value.toUpperCase()}`,
        amount: amt,
        date: '1999-01-01',
        category: activeCategory.value
    }, {
        preserveScroll: true,
        onSuccess: () => { showSaldoModal.value = false; },
        onError: () => alert('Gagal menyimpan penyesuaian saldo.')
    });
};

const openExpenseModal = (expense = null) => {
    if (expense) {
        isExpenseEditing.value = true; editExpenseId.value = expense.id;
        formExpense.description = expense.description;
        formExpense.amount      = expense.amount;
        formExpense.date        = expense.date;
        formExpense.category    = expense.category || activeCategory.value.toLowerCase();
    } else {
        isExpenseEditing.value = false; editExpenseId.value = null;
        Object.assign(formExpense, { description: '', amount: '', date: new Date().toISOString().split('T')[0], category: activeCategory.value.toLowerCase() });
    }
    showExpenseModal.value = true;
};

const submitExpense = () => {
    if (!formExpense.description)                            return alert('Keterangan wajib diisi.');
    if (!formExpense.amount || safeInt(formExpense.amount) <= 0) return alert('Nominal harus lebih dari 0.');
    formExpense.category = activeCategory.value;
    const url = isExpenseEditing.value ? `/expenses/update/${editExpenseId.value}` : '/expenses/store';
    router.post(url, formExpense, {
        preserveScroll: true,
        onSuccess: () => { showExpenseModal.value = false; Object.assign(formExpense, { description: '', amount: '' }); },
        onError:   () => alert('Gagal menyimpan pengeluaran.')
    });
};

const openAdminModal = (admin = null) => {
    if (admin) {
        isAdminEditing.value = true; editAdminId.value = admin.id;
        formAdmin.name = admin.name; formAdmin.email = admin.email;
        formAdmin.password = ''; formAdmin.password_confirmation = '';
    } else {
        isAdminEditing.value = false; editAdminId.value = null;
        Object.assign(formAdmin, { name: '', email: '', password: '', password_confirmation: '' });
    }
    showAdminModal.value = true;
};

const submitAdmin = () => {
    const url = isAdminEditing.value ? `/users/update/${editAdminId.value}` : '/users/store';
    router.post(url, formAdmin, {
        preserveScroll: true,
        onSuccess: (p) => { showAdminModal.value = false; alert(p.props.flash?.message || 'Berhasil menyimpan data admin.'); },
        onError:   (e) => { console.error(e); alert(e?.email || e?.name || 'Gagal menyimpan data admin.'); }
    });
};

const openPaymentModal = (resident) => {
    const fresh = props.wargas.find(w => w.id === resident.id) || resident;
    selectedResident.value  = fresh;
    showPaymentModal.value  = true;
    showAmountOptions.value = null;
    paymentYear.value       = new Date().getFullYear();
};

const togglePayment = async (monthKey, customAmount = null) => {
    if (!currentUser.value) return;
    const dynamicKey  = getHistoryKey(monthKey, paymentYear.value);
    const currentData = selectedResident.value.payment_history?.[dynamicKey];

    if (currentData) {
        if (!confirm(`Batalkan pembayaran ${monthKey.toUpperCase()} ${paymentYear.value}?`)) return;
        await router.post(`/wargas/pay/${selectedResident.value.id}`,
            { month: dynamicKey, amount: null },
            { 
                preserveScroll: true, 
                onSuccess: () => {
                    // ✅ FIX: Sync selectedResident dari props terbaru
                    const updated = props.wargas.find(w => w.id === selectedResident.value.id);
                    if (updated) selectedResident.value = updated;
                    showAmountOptions.value = null;
                },
                onError: () => alert('Gagal membatalkan pembayaran.') 
            }
        );
    } else {
        const amountToPay = customAmount || safeInt(selectedResident.value.tarif || 20000);
        await router.post(`/wargas/pay/${selectedResident.value.id}`,
            { month: dynamicKey, amount: amountToPay },
            { 
                preserveScroll: true, 
                onSuccess: () => {
                    // ✅ FIX: Sync selectedResident dari props terbaru
                    const updated = props.wargas.find(w => w.id === selectedResident.value.id);
                    if (updated) selectedResident.value = updated;
                },
                onError: () => alert('Gagal melakukan pembayaran.') 
            }
        );
    }
};

const openLetterModal = (resident) => {
    selectedResidentForLetter.value = resident;
    showLetterModal.value = true;
};

// ✅ FIX #5 dari review sebelumnya: pakai selectedFinancialYear, bukan currentYear
const getResidentTotalDebt = computed(() => {
    if (!selectedResidentForLetter.value) return 0;
    const r             = selectedResidentForLetter.value;
    const currentMonthIdx = new Date().getMonth();
    let total = 0;
    for (let i = 0; i <= currentMonthIdx; i++) {
        const val = r.payment_history?.[getHistoryKey(MONTH_KEYS[i], selectedFinancialYear.value)];
        if ((typeof val !== 'number' || val === 0) && val !== true) {
            total += safeInt(r.tarif || 20000);
        }
    }
    return total;
});

// ✅ FIX script
const printLetter = () => {
    document.body.classList.add('print-letter');
    window.print();
    document.body.classList.remove('print-letter');
};

const printCard = async () => {
    showAmountOptions.value = null;
    document.body.classList.add('print-card');
    await nextTick();
    window.print();
    document.body.classList.remove('print-card');
};


// ============================================================
// WHATSAPP
// ============================================================
const sendWhatsapp = (resident) => {
    if (!resident.telepon) return alert('Nomor telepon belum diisi.');
    let phone = resident.telepon.toString().replace(/\D/g, '');
    if (phone.startsWith('0')) phone = '62' + phone.substring(1);
    else if (!phone.startsWith('62')) phone = '62' + phone;
    const text = `Halo Bpk/Ibu ${resident.nama} (Blok ${resident.blok}/${resident.nomor}),%0A%0AMengingatkan tagihan air bulan *${MONTH_NAMES[new Date().getMonth()]} ${currentYear}* sebesar *${formatRupiah(resident.tarif || 20000)}* belum lunas.`;
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
};

const generateWhatsappMessage = (resident) => {
    const monthName   = MONTH_NAMES[MONTH_KEYS.indexOf(debtReportMonthKey.value)];
    const year        = selectedFinancialYear.value;
    const amount      = formatRupiah(resident.tarif || 20000);
    const unpaidCount = resident.unpaidCount || 1;
    const pesan = unpaidCount === 1
        ? `tagihan air bulan *${monthName} ${year}* sebesar *${amount}* belum lunas.`
        : `tagihan air selama *${unpaidCount} bulan* terakhir sebesar *${amount}* per bulan belum lunas.`;
    return encodeURI(`Halo Bpk/Ibu ${resident.nama} (Blok ${resident.blok}/${resident.nomor}),%0A%0AMengingatkan ${pesan}%0AMohon segera melakukan pembayaran. Terima kasih.`);
};

// const sendWhatsappDebt = (resident) => {
//     if (!resident.telepon) return alert('Nomor telepon belum diisi.');
//     let phone = resident.telepon.toString().replace(/\D/g, '');
//     if (phone.startsWith('0')) phone = '62' + phone.substring(1);
//     window.open(`https://wa.me/${phone}?text=${generateWhatsappMessage(resident)}`, '_blank');
// };

// ============================================================
// DOWNLOAD
// ============================================================
// const downloadCSV = () => {
//     const monthKey   = selectedMonthKey.value;
//     const year       = selectedFinancialYear.value;
//     const category   = activeCategory.value;
//     const monthIndex = MONTH_KEYS.indexOf(monthKey);
//     const historyKey = getHistoryKey(monthKey, year);
//     const monthName  = MONTH_NAMES[monthIndex];

//     let csv = 'No,Nama Warga,Blok,Nomor,Kategori,Nominal Bayar\n';
//     let no = 1, total = 0;

//     residents.value.forEach(r => {
//         const val = r.payment_history?.[historyKey];
//         if (!val) return;
//         const amount         = (typeof val === 'number') ? val : safeInt(r.tarif || 20000);
//         const categoryAmount = getPaymentDetail(amount, monthIndex, year)[category] || 0;
//         if (categoryAmount <= 0) return;
//         csv += `${no},"${r.nama || '-'}","${r.blok || '-'}","${r.nomor || '-'}",${category.toUpperCase()},${categoryAmount}\n`;
//         total += categoryAmount; no++;
//     });
//     csv += `TOTAL,,,,${total}\n`;

//     const link = document.createElement('a');
//     link.href  = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
//     link.setAttribute('download', `Laporan_${category.toUpperCase()}_${monthName}_${year}.csv`);
//     document.body.appendChild(link); link.click(); document.body.removeChild(link);
// // };

const downloadExcelReport = async () => {
    const monthKey   = selectedMonthKey.value;
    const year       = selectedFinancialYear.value;
    const category   = activeCategory.value.toUpperCase();
    const monthIndex = MONTH_KEYS.indexOf(monthKey);
    const historyKey = getHistoryKey(monthKey, year);
    const monthName  = MONTH_NAMES[monthIndex];

    const workbook = new ExcelJS.Workbook();
    const sheet    = workbook.addWorksheet(`Laporan_${category}_${monthName}_${year}`.replaceAll(' ', '_'));

    sheet.mergeCells('A1:F1');
    const titleCell = sheet.getCell('A1');
    titleCell.value = `Laporan Pemasukan ${category} - ${monthName} ${year}`;
    titleCell.font  = { size: 14, bold: true };
    titleCell.alignment = { vertical: 'middle', horizontal: 'center' };

    sheet.addRow([]);
    const headerRow = sheet.addRow(['No', 'Nama Warga', 'Blok', 'Nomor', 'Kategori', 'Nominal Bayar']);
    headerRow.font = { bold: true };
    headerRow.eachCell(cell => {
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        cell.fill   = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFBDD7EE' } };
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });

    let no = 1, total = 0;
    residents.value.forEach(r => {
        const val = r.payment_history?.[historyKey];
        if (!val) return;
        const amount         = (typeof val === 'number') ? val : safeInt(r.tarif || 20000);
        const categoryAmount = getPaymentDetail(amount, monthIndex, year)[activeCategory.value] || 0;
        if (categoryAmount <= 0) return;
        const nomorRumah = Number(r.nomor);
        const row = sheet.addRow([no, r.nama || '-', r.blok || '-', isNaN(nomorRumah) ? 0 : nomorRumah, category, categoryAmount]);
        row.getCell(4).numFmt = '0';
        row.eachCell(cell => {
            cell.border    = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
            cell.alignment = { horizontal: 'center', vertical: 'middle' };
        });
        no++; total += categoryAmount;
    });

    const totalRow = sheet.addRow(['', '', '', '', 'TOTAL', total]);
    totalRow.font = { bold: true };
    totalRow.getCell(6).numFmt = '"Rp"#,##0';
    totalRow.eachCell(cell => {
        cell.border = { top: { style: 'thick' }, left: { style: 'thick' }, bottom: { style: 'thick' }, right: { style: 'thick' } };
    });

    sheet.columns.forEach(col => {
        let max = 10;
        col.eachCell({ includeEmpty: true }, cell => {
            max = Math.max(max, (cell.value?.toString() || '').length + 2);
        });
        col.width = Math.min(max, 25);
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
        `Laporan_${category}_${monthName}_${year}.xlsx`);
};

const inventarisList     = computed(() => props.inventaris || []);
const showInventarisModal = ref(false);
const isInventarisEditing = ref(false);
const editInventarisId    = ref(null);

const formInventaris = reactive({
    nama_barang: '',
    jumlah:      1,
    kondisi:     'baik',
    keterangan:  '',
    foto:        null,      // File object dari input
    fotoPreview: null,      // URL preview di browser
});

// Fungsi kompresi gambar client-side untuk menghindari limit upload server
const compressImage = (file) => {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const MAX_SIZE = 1200;

                if (width > height) {
                    if (width > MAX_SIZE) {
                        height *= MAX_SIZE / width;
                        width = MAX_SIZE;
                    }
                } else {
                    if (height > MAX_SIZE) {
                        width *= MAX_SIZE / height;
                        height = MAX_SIZE;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                canvas.toBlob((blob) => {
                    const newFile = new File([blob], file.name, {
                        type: 'image/jpeg',
                        lastModified: Date.now()
                    });
                    resolve(newFile);
                }, 'image/jpeg', 0.7); // 70% quality
            };
        };
    });
};

// ✅ SESUDAH - revoke URL lama sebelum buat baru, ditambah kompresi otomatis
const handleFotoChange = async (event) => {
    let file = event.target.files[0];
    if (!file) return;
    
    // Bebaskan URL lama jika bukan dari server
    if (formInventaris.fotoPreview && formInventaris.fotoPreview.startsWith('blob:')) {
        URL.revokeObjectURL(formInventaris.fotoPreview);
    }
    
    // Kompres file jika gambarnya besar (>1MB)
    if (file.type.startsWith('image/') && file.size > 1024 * 1024) {
        file = await compressImage(file);
    }
    
    formInventaris.foto = file;
    formInventaris.fotoPreview = URL.createObjectURL(file);
};

const openInventarisModal = (item = null) => {
    if (item) {
        isInventarisEditing.value = true;
        editInventarisId.value    = item.id;
        formInventaris.nama_barang = item.nama_barang;
        formInventaris.jumlah      = item.jumlah;
        formInventaris.kondisi     = item.kondisi;
        formInventaris.keterangan  = item.keterangan || '';
        formInventaris.foto        = null;
        formInventaris.fotoPreview = item.foto_url || null;
    } else {
        isInventarisEditing.value = false;
        editInventarisId.value    = null;
        Object.assign(formInventaris, {
            nama_barang: '', jumlah: 1, kondisi: 'baik',
            keterangan: '', foto: null, fotoPreview: null
        });
    }
    showInventarisModal.value = true;
};

// ✅ SESUDAH - tambah validasi dasar
const submitInventaris = () => {
    if (!formInventaris.nama_barang.trim()) return alert('Nama barang wajib diisi.');
    if (!formInventaris.jumlah || formInventaris.jumlah < 1) return alert('Jumlah minimal 1.');
    
    const url = isInventarisEditing.value
        ? `/inventaris/update/${editInventarisId.value}`
        : '/inventaris/store';

    const formData = new FormData();
    formData.append('nama_barang', formInventaris.nama_barang);
    formData.append('jumlah',      formInventaris.jumlah);
    formData.append('kondisi',     formInventaris.kondisi);
    formData.append('keterangan',  formInventaris.keterangan || '');
    if (formInventaris.foto) {
        formData.append('foto', formInventaris.foto);
    }

    router.post(url, formData, {
        preserveScroll: true,
        onSuccess: () => { showInventarisModal.value = false; },
        onError:   (e) => { console.error(e); alert('Gagal menyimpan inventaris.'); }
    });
};
const deleteInventaris = (id) => {
    if (!confirm('Hapus inventaris ini?')) return;
    router.post(`/inventaris/delete/${id}`, {}, {
        preserveScroll: true,
        onSuccess: () => alert('Inventaris dihapus.'),
        onError:   () => alert('Gagal menghapus.')
    });
};

const kondisiLabel = (kondisi) => {
    const labels = {
        'baik': 'Layak',
        'rusak': 'Rusak',
        'perlu_servis': 'Servis'
    };
    return labels[kondisi] || kondisi;
};

const kondisiBadge = (kondisi) => {
    switch (kondisi) {
        case 'baik': 
            return 'bg-emerald-500 text-white border-emerald-600';
        case 'rusak': 
            return 'bg-rose-600 text-white border-rose-700';
        case 'perlu_servis': 
            return 'bg-amber-400 text-amber-950 border-amber-500';
        default: 
            return 'bg-slate-500 text-white border-slate-600';
    }
};

// ✅ Tambahkan setelah deklarasi formInventaris
watch(showInventarisModal, (val) => {
    if (!val) {
        if (formInventaris.fotoPreview?.startsWith('blob:')) {
            URL.revokeObjectURL(formInventaris.fotoPreview);
        }
        Object.assign(formInventaris, {
            nama_barang: '', jumlah: 1, kondisi: 'baik',
            keterangan: '', foto: null, fotoPreview: null
        });
        isInventarisEditing.value = false;
        editInventarisId.value    = null;
    }
});


// Fungsi untuk Tambah
// const submitInventaris = () => {
//     router.post('/inventaris/store', formInventaris, {
//         forceFormData: true,
//         onSuccess: () => {
//             showAddInventarisModal.value = false;
//             formInventaris.reset();
//         }
//     });
// };

// Fungsi untuk Update
const submitEditInventaris = () => {
    router.post(`/inventaris/update/${formEditInventaris.id}`, {
        ...formEditInventaris,
    }, {
        forceFormData: true,
        onSuccess: () => {
            showEditInventarisModal.value = false;
        }
    });
};

</script>

<template>
  <div> 
    <Head title="Dashboard" />

    <div class="min-h-screen bg-[#F8FAFC] font-sans text-slate-800 pb-24 md:pb-10">
        <nav class="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-lg border-b border-slate-200/50 shadow-sm transition-all">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex h-16 items-center justify-between">
                    <div class="flex items-center gap-3 cursor-pointer group" @click="activeTab = 'dashboard'">
                        <div class="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/20 transition-transform group-hover:scale-105"><Waves :size="20" class="text-white" /></div>
                        <div class="flex flex-col"><h1 class="text-xl font-extrabold tracking-tight text-slate-800">Laporan <span class="text-blue-600">NMR</span></h1></div>
                    </div>
                    <div class="hidden md:flex items-center bg-slate-100 p-1.5 rounded-full border border-slate-200">
    <button v-for="tab in visibleTabs" :key="tab.id" @click="activeTab = tab.id" 
        :class="['flex items-center gap-2 px-5 py-2 rounded-full text-xs font-bold transition-all duration-300', 
        activeTab === tab.id ? 'bg-white text-blue-600 shadow-sm ring-1 ring-black/5' : 'text-slate-500 hover:text-slate-900 hover:bg-white/50']">
        <component :is="tab.icon" :size="16" :class="{ 'stroke-[2.5px]': activeTab === tab.id }" /> 
        {{ tab.label }}
    </button>
</div>
                    <div class="flex items-center gap-3">
                        <div v-if="currentUser" class="hidden md:flex items-center gap-3 pl-4 border-l border-slate-200">
                            <div class="text-right"><p class="text-xs font-bold text-slate-800">{{ currentUser?.name }}</p><p class="text-[10px] text-slate-500">Admin</p></div>
                            <Link href="/logout" method="post" as="button" class="bg-white border border-slate-200 text-slate-500 hover:bg-red-50 hover:text-red-500 hover:border-red-200 p-2 rounded-xl transition-all shadow-sm" title="Logout"><LogOut :size="18" /></Link>
                        </div>
                        <div v-else class="hidden md:block"><Link href="/login" class="flex items-center gap-2 bg-slate-900 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all"><LogIn :size="16" /> Login</Link></div>
                        <button @click="isMobileMenuOpen = !isMobileMenuOpen" class="md:hidden p-2 text-slate-600 bg-white border border-slate-100 rounded-lg shadow-sm hover:bg-slate-50 transition"><Menu v-if="!isMobileMenuOpen" :size="24" /> <X v-else :size="24" /></button>
                    </div>
                </div>
            </div>
            <div v-if="isMobileMenuOpen" class="md:hidden absolute top-16 inset-x-0 bg-white border-b border-slate-100 shadow-xl p-4 flex flex-col gap-2 z-50 animate-in slide-in-from-top-2">
                <button v-for="tab in visibleTabs" :key="tab.id" @click="activeTab=tab.id; isMobileMenuOpen=false" :class="['p-4 rounded-xl text-left font-bold flex gap-3 capitalize text-sm', activeTab===tab.id ? 'bg-blue-50 text-blue-600' : 'text-slate-600 hover:bg-slate-50']"><component :is="tab.icon" :size="18" /> {{ tab.label }}</button>
                <div class="border-t pt-3 mt-1" v-if="!currentUser"><Link href="/login" class="flex justify-center items-center gap-2 bg-slate-900 text-white w-full p-3 rounded-lg text-sm font-bold shadow"><LogIn :size="14" /> Login Admin</Link></div>
                <div class="border-t pt-3 mt-1 flex justify-between items-center" v-else><span class="font-bold text-slate-700 ml-2 text-sm">Halo, {{ currentUser?.name }}</span><Link href="/logout" method="post" as="button" class="bg-red-50 text-red-600 font-bold px-3 py-1.5 rounded text-xs">Logout</Link></div>
            </div>
        </nav>

        <main class="max-w-full mx-auto px-2 sm:px-4 py-8">

            <div v-if="activeTab === 'dashboard'" class="animate-in fade-in zoom-in duration-300">
    <div class="flex flex-col md:flex-row justify-between items-end gap-4 mb-6">
        <div>
            <h2 class="text-3xl font-extrabold text-slate-800 tracking-tight">Data Warga</h2>
            <p class="text-slate-500 text-sm mt-1">Daftar hunian blok Nuansa Manisi Regency.</p>
        </div>
        <div class="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
    <div class="relative group w-full sm:w-64">
        <Search :size="18" class="absolute left-3 top-3 text-slate-400 group-focus-within:text-blue-500 transition-colors"/>
        
        <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="Cari nama atau blok..." 
            class="w-full pl-10 pr-10 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
        >

        <button 
            v-if="searchQuery" 
            @click="searchQuery = ''" 
            class="absolute right-3 top-3 text-slate-400 hover:text-red-500 transition-colors focus:outline-none"
            title="Hapus Pencarian"
        >
            <X :size="18" />
        </button>
    </div>

    <button v-if="currentUser" @click="openResidentModal()" class="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5 hover:shadow-lg active:scale-95">
        <Plus :size="18" /> 
        <span class="hidden sm:inline">Tambah Warga</span>
        <span class="sm:hidden">Tambah</span>
    </button>
</div>
    </div>

    <div v-for="(wargas, blockName) in groupedResidents" :key="blockName" class="mb-4 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden transition-all duration-300">
        <div @click="toggleBlock(blockName)" class="p-4 flex justify-between items-center cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors select-none">
            <div class="flex items-center gap-3">
                <div class="bg-slate-800 text-white p-1.5 rounded-lg shadow-sm"><MapPin :size="18"/></div>
                <h3 class="text-lg font-bold text-slate-800">Blok {{ blockName }}</h3>
                <span class="text-xs font-bold bg-white border border-slate-200 text-slate-500 px-2.5 py-1 rounded-full shadow-sm">{{ wargas.length }} Rumah</span>
            </div>
            <ChevronDown :size="20" class="text-slate-400 transition-transform duration-300" :class="{'rotate-180': openBlocks[blockName]}" />
        </div>
        <div v-show="openBlocks[blockName]" class="p-4 bg-white border-t border-slate-100 animate-in slide-in-from-top-2">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <div v-for="r in wargas" :key="r.id" class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-blue-300 transition-all relative group">
                    <div class="flex justify-between items-start mb-3">
                        <span class="bg-slate-50 text-slate-600 border border-slate-200 px-2.5 py-1 rounded-md text-xs font-bold flex items-center gap-1.5"><Home :size="12" /> {{ r.blok }} / {{ r.nomor }}</span>
                        <div v-if="currentUser" class="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button v-if="r.telepon" @click="sendWhatsapp(r)" class="text-green-500 hover:bg-green-50 p-1 rounded" title="WA"><MessageCircle :size="14"/></button>
                            <button @click="openResidentModal(r)" class="text-slate-400 hover:text-yellow-600 p-1"><Edit2 :size="14"/></button>
                            <button @click="deleteItem('resident', r.id)" class="text-slate-400 hover:text-red-600 p-1"><Trash2 :size="14"/></button>
                        </div>
                    </div>
                    <h3 class="font-bold text-slate-800 text-lg mb-2 truncate" :title="r.nama">{{ r.nama }}</h3>
                    <div class="mb-4">
                        <span :class="['text-[10px] px-2 py-1 rounded font-bold border flex w-fit items-center gap-1.5', r.tarif >= 50000 ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-blue-50 text-blue-700 border-blue-200']">
                            <Banknote :size="12" /> Tagihan: {{ formatRupiah(r.tarif || 20000) }}
                        </span>
                    </div>
                    <button @click="openPaymentModal(r)" class="w-full py-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold shadow-sm hover:bg-slate-50 hover:text-blue-600 hover:border-blue-300 transition flex items-center justify-center gap-2 group-hover:border-blue-200">
                        <History :size="14"/> Cek & Bayar
                    </button>
                </div>
            </div>
        </div>
    </div>

   <div v-if="activeTab === 'dashboard'" class="mt-12 bg-white rounded-[2rem] shadow-sm border border-slate-200 overflow-hidden shadow-slate-200">
    <div class="p-6 border-b border-slate-50 bg-red-50/20 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div class="flex items-center gap-4">
            <div class="h-12 w-12 flex items-center justify-center rounded-2xl bg-red-100 text-red-600 shadow-sm">
                <AlertTriangle :size="24"/>
            </div>
            <div>
                <h3 class="text-xl font-black text-slate-800 uppercase tracking-tighter">Daftar Warga</h3>
                <p class="text-xs text-slate-400 font-bold uppercase tracking-widest">Warga yang belum melunasi iuran bulan ini</p>
            </div>
        </div>
        
        <div class="flex items-center gap-2 bg-white p-1.5 rounded-2xl border border-red-100 shadow-sm">
            <select v-model="debtReportMonthKey" class="bg-transparent border-none text-xs font-black uppercase p-2 outline-none cursor-pointer text-red-600 focus:ring-0">
                <option v-for="m in MONTHS" :key="m.key" :value="m.key">{{ m.label }}</option>
            </select>
            <div class="px-4 py-2 bg-red-600 text-white rounded-xl font-black text-xs">
                {{ overdueResidents.length }} Unit
            </div>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest border-b">
    <tr>
        <th class="p-5 pl-8">Identitas Warga</th>
        <th class="p-5">Unit</th>
        <th class="p-5">Status</th>
        <th class="p-5">Tunggakan</th> <!-- Tambahkan kolom baru -->
        <th v-if="currentUser" class="p-5 text-center">Aksi Admin</th>
    </tr>
</thead>
           <!-- Ganti bagian <tbody> tabel dengan kode ini -->
<tbody class="divide-y divide-slate-50">
    <tr v-for="r in overdueResidentsWithCount" :key="r.id" class="group hover:bg-red-50/30 transition-colors">
        <td class="p-5 pl-8 font-bold text-slate-700">{{ r.nama }}</td>
        <td class="p-5">
            <span class="bg-slate-100 px-2 py-1 rounded-lg text-xs font-bold text-slate-600 border border-slate-200">{{ r.blok }} / {{ r.nomor }}</span>
        </td>
        <td class="p-5">
            <span class="bg-red-50 text-red-600 border border-red-100 px-2 py-1 rounded-md text-[10px] font-black uppercase">Belum Bayar</span>
        </td>
    <td class="p-5 tunggakan-cell">{{ r.unpaidCount }} bulan</td>
        <td v-if="currentUser" class="p-5 text-center">
            <button @click="openPaymentModal(r)" class="bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase shadow-md hover:bg-blue-600 transition-all">
                Bayar Sekarang
            </button>
        </td>
    </tr>
</tbody>
        </table>
    </div>
</div>

    <div v-if="Object.keys(groupedResidents).length === 0" class="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-slate-200 mt-4">
        <div class="inline-flex bg-slate-50 p-4 rounded-full mb-3"><User :size="32" class="text-slate-300"/></div>
        <p class="text-slate-500 font-medium">Tidak ada data warga ditemukan.</p>
    </div>
</div>

            <div v-if="activeTab === 'finance'" class="animate-in slide-in-from-bottom-4 duration-500">
                <div class="flex flex-col md:flex-row justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100 mb-6 gap-3">
                    <div>
                        <h3 class="text-lg font-bold text-slate-800">Laporan Keuangan</h3>
                        <div class="flex gap-2 mt-1">
                            <button @click="financeViewMode = 'monthly'" :class="['px-3 py-1 text-xs font-bold rounded-lg border transition', financeViewMode === 'monthly' ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-500 border-slate-200']">Bulanan</button>
                            <button @click="financeViewMode = 'yearly'" :class="['px-3 py-1 text-xs font-bold rounded-lg border transition', financeViewMode === 'yearly' ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-50 text-slate-500 border-slate-200']">Tahunan</button>
                        </div>
                    </div>
                    
                    <div class="flex gap-2 w-full md:w-auto">
                        <select v-if="financeViewMode === 'monthly'" v-model="selectedMonthKey" class="bg-slate-50 border-none text-sm font-bold text-slate-700 rounded-xl py-2 pl-3 pr-8 focus:ring-2 focus:ring-blue-500 cursor-pointer hover:bg-slate-100 transition"><option v-for="m in MONTHS" :key="m.key" :value="m.key">{{ m.label }}</option></select>
                        <select v-model="selectedFinancialYear" class="bg-slate-50 border-none text-sm font-bold text-slate-700 rounded-xl py-2 pl-3 pr-8 focus:ring-2 focus:ring-blue-500 cursor-pointer hover:bg-slate-100 transition"><option v-for="y in availableYears" :key="y" :value="y">{{ y }}</option></select>
                        <button @click="downloadExcelReport()" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md active:scale-95 transition"><Download :size="16" /> <span class="hidden sm:inline">Excel</span></button>
                    </div>
                </div>
                    
<div class="flex gap-3 mb-4">
  <!-- Tombol Air -->
  <button
    @click="activeCategory = 'air'"
    :class="[
      'px-4 py-1 text-xs rounded-full font-semibold transition-colors duration-300 cursor-pointer select-none border',
      activeCategory === 'air' 
        ? 'bg-blue-600 text-white border-blue-600' 
        : 'bg-white text-blue-600 border-blue-600 hover:bg-blue-50'
    ]"
  >
    Air
  </button>


 <!-- Tombol Sampah -->
<button
  @click="activeCategory = 'sampah'"
  :class="[
    'px-4 py-1 text-xs rounded-full font-semibold transition-colors duration-300 cursor-pointer select-none border',
    activeCategory === 'sampah' 
      ? 'bg-green-600 text-white border-green-600' 
      : 'bg-white text-green-600 border-green-600 hover:bg-green-50'
  ]"
>
  Sampah
</button>

  <!-- Tombol Kas -->
  <button
    @click="activeCategory = 'kas'"
    :class="[
      'px-4 py-1 text-xs rounded-full font-semibold transition-colors duration-300 cursor-pointer select-none border',
      activeCategory === 'kas' 
        ? 'bg-purple-600 text-white border-purple-600' 
        : 'bg-white text-purple-600 border-purple-600 hover:bg-purple-50'
    ]"
  >
    Kas
  </button>
</div>
              <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

  <!-- Pemasukan -->
  <div class="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-lg transition-all">
    <div class="flex items-center gap-3 mb-3">
      <div class="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Wallet :size="20"/></div>
      <div>
        <p class="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Pemasukan ({{ selectedMonthKey.toUpperCase() }}, {{ activeCategory.toUpperCase() }})</p>
        <h3 class="text-xl font-extrabold text-slate-800 tracking-tight">
  {{ formatRupiah(financeViewMode === 'monthly' ? currentMonthIncomeByCategory : yearlyTotalIncome) }}
</h3>
      </div>
    </div>
    <button class="w-full mt-1 flex items-center justify-center gap-2 text-xs bg-blue-50 text-blue-600 px-3 py-2 rounded-xl font-bold hover:bg-blue-600 hover:text-white transition" @click="currentUser && openIncomeModal()">
      <Plus :size="14" /> Catat
    </button>
  </div>

  <!-- Pengeluaran -->
  <div class="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-lg transition-all">
    <div class="flex items-center gap-3 mb-3">
      <div class="p-2.5 bg-red-50 text-red-600 rounded-xl"><TrendingDown :size="20"/></div>
      <div>
        <p class="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Pengeluaran ({{ selectedMonthKey.toUpperCase() }}, {{ activeCategory.toUpperCase() }})</p>
        <h3 class="text-xl font-extrabold text-slate-800 tracking-tight">{{ formatRupiah(currentCategoryExpense) }}</h3>
      </div>
    </div>
    <button class="w-full mt-1 flex items-center justify-center gap-2 text-xs bg-red-50 text-red-600 px-3 py-2 rounded-xl font-bold hover:bg-red-600 hover:text-white transition" @click="currentUser && openExpenseModal()">
      <Plus :size="14" /> Catat
    </button>
  </div>

  <!-- Selisih Bulan Ini -->
  <div class="p-5 rounded-3xl shadow-sm border relative overflow-hidden transition-all bg-white border-slate-100">
    <div class="flex items-center gap-3 mb-2">
      <div :class="['p-2.5 rounded-xl', currentCategoryNet >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600']">
        <Calculator :size="20"/>
      </div>
      <div>
        <p class="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Selisih Bulan Ini</p>
        <h3 :class="['text-xl font-extrabold tracking-tight', currentCategoryNet >= 0 ? 'text-emerald-600' : 'text-red-600']">
    {{ currentCategoryNet >= 0 ? '+' : '' }}{{ formatRupiah(currentCategoryNet) }}
</h3>
      </div>
    </div>
    <p class="text-[10px] text-slate-400 font-medium">Pemasukan dikurangi Pengeluaran bulan ini saja.</p>
  </div>

  <!-- Total Saldo Akhir -->
  <div class="bg-gradient-to-br from-slate-800 to-slate-900 p-5 rounded-3xl text-white shadow-xl shadow-slate-900/20 relative overflow-hidden flex flex-col justify-center group">
    <div class="absolute top-0 right-0 p-4 opacity-10"><Scale :size="80" /></div>
    <button v-if="currentUser" @click="openSaldoModal" class="absolute top-3 right-3 p-2 bg-white/10 hover:bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-all text-white active:scale-95" title="Sesuaikan Saldo Akhir">
        <Edit2 :size="16" />
    </button>
    <div>
      <p class="text-slate-300 text-[10px] font-bold uppercase tracking-wider mb-1">Total Saldo Akhir ({{ selectedMonthKey.toUpperCase() }}, {{ activeCategory.toUpperCase() }})</p>
      <h2 class="text-2xl font-extrabold tracking-tight mb-1">{{ formatRupiah(runningBalanceByCategory) }}</h2>
      <div class="text-[10px] text-slate-400 font-medium">Termasuk saldo dari bulan lalu.</div>
    </div>
  </div>

</div>

             <div v-if="financeViewMode === 'monthly'" class="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in">
  <!-- Rincian Pemasukan -->
 <div class="bg-white rounded-lg shadow border overflow-hidden flex flex-col h-[400px]">
    <div class="p-4 border-b border-slate-50 bg-slate-50/50">
        <h4 class="text-sm font-bold text-slate-700 flex items-center gap-2">
            <TrendingUp class="w-4 h-4 text-blue-500" />
            Rincian Pemasukan ({{ selectedMonthKey.substring(0, 3).toUpperCase() }})
        </h4>
    </div>

    <div class="overflow-auto flex-1">
        <table class="w-full text-left text-sm">
            <thead class="sticky top-0 bg-white shadow-sm z-10">
                <tr class="text-slate-400 text-[10px] uppercase border-b border-slate-100">
                    <th class="p-3 pl-4">Keterangan</th>
                    <th class="p-3 text-center">Info</th>
                    <th class="p-3 text-right pr-4">Jml</th>
                    <th class="w-8"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-50">
                <tr v-for="(item, index) in detailedIncomeList" :key="index" 
                    :class="item.type === 'manual' ? 'bg-blue-50/30 group' : 'group hover:bg-slate-50'">
                    
                    <td class="p-3 pl-4">
                        <span class="font-medium" :class="item.type === 'manual' ? 'text-blue-700' : 'text-slate-700'">
                            {{ item.keterangan }}
                        </span>
                    </td>
                    
                    <td class="p-3 text-center text-[10px] text-slate-500">
                        {{ item.info }}
                    </td>
                    
                    <td class="p-3 text-right pr-4 font-mono font-bold" 
                        :class="item.type === 'manual' ? 'text-blue-600' : 'text-green-600'">
                        +Rp {{ item.amount.toLocaleString('id-ID') }}
                    </td>

                    <td class="p-3">
                        <div v-if="item.type === 'manual'" class="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button @click="openIncomeModal(item)" class="text-yellow-500 hover:text-yellow-600"><Edit2 size="14"/></button>
                            <button @click="deleteIncome(item.id)" class="text-red-500 hover:text-red-600"><Trash2 size="14"/></button>
                        </div>
                    </td>
                </tr>

                <tr v-if="detailedIncomeList.length === 0">
                    <td colspan="4" class="p-10 text-center text-slate-400 italic text-xs">
                        Belum ada pemasukan untuk kategori {{ activeCategory }}
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

  <!-- Rincian Pengeluaran -->
  <div class="bg-white p-4 rounded-lg shadow border overflow-auto h-[400px] flex flex-col">
    <h4 class="font-bold text-slate-700 flex items-center gap-2 mb-3">
      <TrendingDown size="16" class="text-red-500" />
      Rincian Pengeluaran ({{ selectedMonthKey.toUpperCase() }})
    </h4>
    <table class="w-full text-left text-sm">
      <thead class="sticky top-0 bg-white shadow z-10">
        <tr class="text-slate-400 text-[10px] uppercase border-b border-slate-100">
          <th class="p-3 pl-4">Keterangan</th>
          <th class="p-3 text-center">Tgl</th>
          <th class="p-3 text-right pr-4">Jml</th>
          <th v-if="currentUser" class="p-3 w-[50px]"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-50">
        <tr v-for="exp in filteredExpensesByCategory" :key="exp.id" class="group hover:bg-red-50/30">
          <td class="p-3 pl-4 font-medium text-slate-700">{{ exp.description }}</td>
          <td class="p-3 text-center text-xs text-slate-500">{{ formatDate(exp.date) }}</td>
          <td class="p-3 text-right pr-4 font-mono font-bold text-red-600">-{{ formatRupiah(exp.amount) }}</td>
          <td v-if="currentUser" class="p-3 text-right">
            <div class="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button @click="openExpenseModal(exp)" class="text-yellow-500 hover:text-yellow-600"><Edit2 size="14"/></button>
              <button @click="deleteItem('expense', exp.id)" class="text-red-500 hover:text-red-600"><Trash2 size="14"/></button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

                <div v-else class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in">
                    <div class="p-4 border-b border-slate-50 bg-slate-50/50"><h4 class="text-sm font-bold text-slate-700 flex items-center gap-2"><Calendar :size="16" class="text-blue-500"/> Rekapitulasi Tahunan ({{ selectedFinancialYear }})</h4></div>
                   <div class="overflow-x-auto custom-scrollbar">
    <table class="w-full min-w-[600px] text-left border-collapse">
        <thead class="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-widest border-b">
            <tr>
                <th class="p-4 pl-6">Warga</th>
                <th class="p-4 text-center">Unit</th>
                <th class="p-4 text-center">Status</th>
                <th class="p-4 text-right">Tagihan</th>
                <th v-if="currentUser" class="p-4 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-50">
            <tr v-for="r in overdueResidents" :key="r.id" class="hover:bg-slate-50 transition-colors">
                <td class="p-4 pl-6 font-bold text-slate-700 text-sm whitespace-nowrap">
                    {{ r.nama }}
                </td>
                
                <td class="p-4 text-center">
                    <span class="inline-block min-w-[60px] bg-slate-100 px-2 py-1 rounded-lg text-[10px] font-black text-slate-600 border border-slate-200">
                        {{ r.blok }} / {{ r.nomor }}
                    </span>
                </td>
                
                <td class="p-4 text-center">
                    <span class="inline-block whitespace-nowrap bg-red-50 text-red-600 border border-red-100 px-2 py-1 rounded-md text-[9px] font-black uppercase">
                        Belum Bayar
                    </span>
                </td>
                
                <td class="p-4 text-right font-black text-red-600 text-sm whitespace-nowrap">
                    {{ formatRupiah(r.tarif) }}
                </td>
                
                <!-- Ganti bagian <td> untuk Aksi dengan ini -->
<td v-if="currentUser" class="p-5 text-center">
    <div class="flex flex-col gap-2 items-center">
        <!-- Tombol Bayar -->
        <button @click="openPaymentModal(r)" class="w-full bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-blue-600">
            Bayar
        </button>
        
        <!-- Tombol Cetak Surat Tagihan (Baru) -->
        <button @click="openLetterModal(r)" class="w-full bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-slate-50 hover:text-slate-900">
            Cetak Surat
        </button>
    </div>
</td>
            </tr>
        </tbody>
    </table>
</div>
                </div>
            </div>

            <!-- ===== TAB INVENTARIS ===== -->
<div v-if="activeTab === 'inventaris'" class="animate-in fade-in zoom-in duration-300">
    
    <!-- Header -->
    <div class="flex flex-col md:flex-row justify-between items-end gap-4 mb-6">
        <div>
            <h2 class="text-3xl font-extrabold text-slate-800 tracking-tight">Inventaris</h2>
            <p class="text-slate-500 text-sm mt-1">Daftar aset dan peralatan warga perumahan.</p>
        </div>
        <button 
            v-if="currentUser" 
            @click="openInventarisModal()" 
            class="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:-translate-y-0.5 hover:shadow-lg transition-all active:scale-95"
        >
            <Plus :size="18"/> Tambah Barang
        </button>
    </div>

    <!-- Grid Kartu Barang -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <div 
            v-for="item in inventarisList" :key="item.id"
            class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:border-blue-300 hover:shadow-md transition-all group"
        >
            <!-- Foto Barang -->
<td class="px-6 py-4 whitespace-nowrap">
    <div class="flex items-center">
        <div class="w-24 h-24 md:w-32 md:h-32 rounded-xl overflow-hidden bg-slate-100 border-2 border-slate-200 group relative shadow-sm">
    
    <img 
        v-if="item.foto_url" 
        :src="item.foto_url" 
        :alt="item.nama_barang"
        class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
    >
    
    <div v-else class="w-full h-full flex items-center justify-center">
        <Package :size="40" class="text-slate-300"/>
    </div>

    <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none"></div>

    <span :class="[
        'absolute top-2 right-2 text-[10px] font-black px-2 py-1 rounded-full border shadow-md z-10 uppercase tracking-tighter',
        kondisiBadge(item.kondisi)
    ]">
        {{ kondisiLabel(item.kondisi) }}
    </span>
    
</div>
    </div>
</td>

            <!-- Info Barang -->
            <div class="p-4">
                <h3 class="font-bold text-slate-800 text-base truncate mb-1" :title="item.nama_barang">
                    {{ item.nama_barang }}
                </h3>
                <p class="text-xs text-slate-500 mb-3 line-clamp-2">
                    {{ item.keterangan || 'Tidak ada keterangan' }}
                </p>
                <div class="flex justify-between items-center">
                    <span class="bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1 rounded-lg text-xs font-bold">
                        Jumlah: {{ item.jumlah }}
                    </span>
                    <!-- Tombol Edit/Hapus (hanya admin) -->
                    <div v-if="currentUser" class="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button @click="openInventarisModal(item)" class="p-1.5 text-yellow-500 hover:bg-yellow-50 rounded-lg transition">
                            <Edit2 :size="14"/>
                        </button>
                        <button @click="deleteInventaris(item.id)" class="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition">
                            <Trash2 :size="14"/>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Empty State -->
        <div v-if="inventarisList.length === 0" 
             class="col-span-full text-center py-20 bg-white rounded-3xl border-2 border-dashed border-slate-200">
            <div class="inline-flex bg-slate-50 p-4 rounded-full mb-3">
                <Package :size="32" class="text-slate-300"/>
            </div>
            <p class="text-slate-500 font-medium">Belum ada data inventaris.</p>
        </div>
    </div>
</div>

<!-- ===== MODAL TAMBAH/EDIT INVENTARIS ===== -->
<div v-if="showInventarisModal" 
     @click.self="showInventarisModal = false"
     class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
    
    <div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative max-h-[90vh] overflow-y-auto">
        
        <button @click="showInventarisModal = false" 
                class="absolute top-4 right-4 p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 transition-all">
            <X :size="20"/>
        </button>

        <h3 class="text-xl font-bold text-slate-800 mb-5">
            {{ isInventarisEditing ? 'Edit Barang' : 'Tambah Barang' }}
        </h3>

        <div class="space-y-4">

            <!-- Preview Foto -->
            <div class="relative w-full h-48 bg-slate-100 rounded-xl overflow-hidden border-2 border-dashed border-slate-300 flex items-center justify-center">
                <img v-if="formInventaris.fotoPreview" 
                     :src="formInventaris.fotoPreview" 
                     class="w-full h-full object-cover"/>
                <div v-else class="text-center">
                    <Package :size="32" class="text-slate-300 mx-auto mb-2"/>
                    <p class="text-xs text-slate-400">Belum ada foto</p>
                </div>
                
               <!-- ✅ SESUDAH - 2 tombol: Kamera & Galeri -->
<div class="absolute bottom-2 right-2 flex gap-2">
    
    <!-- Tombol Kamera Langsung -->
    <label class="bg-blue-600 text-white px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer hover:bg-blue-700 transition flex items-center gap-1.5 shadow-md">
        📷 Kamera
        <input 
            type="file" 
            accept="image/*" 
            capture="environment"
            class="hidden"
            @change="handleFotoChange"
        >
    </label>

    <!-- Tombol Pilih dari Galeri -->
    <label class="bg-slate-900 text-white px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer hover:bg-slate-700 transition flex items-center gap-1.5 shadow-md">
        🖼️ Galeri
        <input 
            type="file" 
            accept="image/*"
            class="hidden"
            @change="handleFotoChange"
        >
    </label>

</div>
            </div>

            <!-- Nama Barang -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Nama Barang</label>
                <input 
                    v-model="formInventaris.nama_barang"
                    class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm"
                    placeholder="Contoh: Mesin Babat Rumput"
                >
            </div>

            <!-- Jumlah -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Jumlah</label>
                <input 
                    v-model="formInventaris.jumlah"
                    type="number" min="1"
                    class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm"
                    placeholder="1"
                >
            </div>

            <!-- Kondisi -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Kondisi</label>
                <div class="grid grid-cols-3 gap-2 mt-1">
                    <button type="button" @click="formInventaris.kondisi = 'baik'"
                        :class="['p-2.5 rounded-xl text-xs font-bold border transition', 
                                 formInventaris.kondisi === 'baik' 
                                 ? 'bg-green-50 border-green-500 text-green-700' 
                                 : 'bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100']">
                        ✅ Baik
                    </button>
                    <button type="button" @click="formInventaris.kondisi = 'perlu_servis'"
                        :class="['p-2.5 rounded-xl text-xs font-bold border transition',
                                 formInventaris.kondisi === 'perlu_servis'
                                 ? 'bg-yellow-50 border-yellow-500 text-yellow-700'
                                 : 'bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100']">
                        ⚠️ Servis
                    </button>
                    <button type="button" @click="formInventaris.kondisi = 'rusak'"
                        :class="['p-2.5 rounded-xl text-xs font-bold border transition',
                                 formInventaris.kondisi === 'rusak'
                                 ? 'bg-red-50 border-red-500 text-red-700'
                                 : 'bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100']">
                        ❌ Rusak
                    </button>
                </div>
            </div>

            <!-- Keterangan -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Keterangan (opsional)</label>
                <textarea
                    v-model="formInventaris.keterangan"
                    rows="3"
                    class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-medium text-sm resize-none"
                    placeholder="Catatan tambahan tentang barang ini..."
                ></textarea>
            </div>

            <!-- Tombol Simpan -->
            <button @click="submitInventaris"
                class="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 hover:shadow-lg transition-all active:scale-95 text-sm">
                {{ isInventarisEditing ? 'Simpan Perubahan' : 'Tambah Barang' }}
            </button>
        </div>
    </div>
</div>

            <div v-if="activeTab === 'settings' && currentUser" class="animate-in fade-in zoom-in duration-300">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100"><div class="flex justify-between items-center mb-4"><h3 class="text-lg font-bold text-slate-800">Daftar Admin</h3><button @click="openAdminModal()" class="bg-slate-900 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-slate-800"><Plus :size="14"/> Tambah</button></div><ul class="space-y-3"><li v-for="u in adminList" :key="u.id" class="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-100"><div><p class="font-bold text-sm text-slate-800">{{ u.name }}</p><p class="text-xs text-slate-500">{{ u.email }}</p></div><div class="flex gap-2"><button @click="openAdminModal(u)" class="text-yellow-600 hover:bg-yellow-50 p-2 rounded-lg transition"><Edit2 :size="16"/></button><button v-if="currentUser && u.id !== currentUser.id" @click="deleteItem('admin', u.id)" class="text-red-500 hover:bg-red-50 p-2 rounded-lg"><Trash2 :size="16"/></button></div></li></ul></div>
                    <div class="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col justify-center items-center text-center"><div class="p-4 bg-yellow-50 rounded-full text-yellow-600 mb-3"><Lock :size="32"/></div><h3 class="text-lg font-bold text-slate-800">Ganti Password</h3><p class="text-xs text-slate-500 mb-4 px-4">Amankan akun anda.</p><Link href="/profile" class="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-yellow-500/30 transition">Buka Halaman Profil</Link></div>
                </div>
            </div>

            <div v-if="showResidentModal" @click.self="showResidentModal=false" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
    <div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative max-h-[90vh] overflow-y-auto">
        
        <button @click="showResidentModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90">
            <X :size="20"/>
        </button>
        
        <h3 class="text-xl font-bold text-slate-800 mb-4">{{ isEditing ? 'Edit Data' : 'Tambah Warga' }}</h3>
        
        <div class="space-y-4">
            <!-- Input Nama -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Nama</label>
                <input v-model="formResident.nama" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" placeholder="Nama Kepala Keluarga">
            </div>
            
            <!-- Input Tarif -->
            <!-- Input Tarif -->
<!-- Ganti blok tipe tarif menjadi readonly spanned -->
<div>
  <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Tipe Tarif</label>
  <div class="grid grid-cols-2 gap-2 mt-1">
    <button 
      type="button" 
      @click="formResident.tarif = 20000" 
      :class="['p-3 rounded-xl text-sm font-bold border transition', formResident.tarif === 20000 ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100']"
    >
      20 Ribu
    </button>

    <button 
      type="button" 
      @click="formResident.tarif = 50000" 
      :class="['p-3 rounded-xl text-sm font-bold border transition', formResident.tarif === 50000 ? 'bg-purple-50 border-purple-500 text-purple-700 ring-1 ring-purple-500' : 'bg-slate-50 border-transparent text-slate-500 hover:bg-slate-100']"
    >
      50 Ribu
    </button>
  </div>
</div>
            
            <!-- Input Blok & Nomor -->
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Blok</label>
                    <input v-model="formResident.blok" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-center text-sm" placeholder="A">
                </div>
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Nomor</label>
                    <input v-model="formResident.nomor" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-center text-sm" placeholder="01">
                </div>
            </div>
            
            <!-- Input Telepon -->
            <div>
                <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Telepon</label>
                <input v-model="formResident.telepon" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm" placeholder="0812...">
            </div>

            <!-- TOGGLE SWITCH ON/OFF (STATUS) -->
            <div class="flex items-center justify-between mt-4 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                    <p class="text-xs font-bold text-slate-800 uppercase">Status Kepemilikan</p>
                    <p class="text-[10px] text-slate-500">Matikan jika warga sudah pindah</p>
                </div>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" v-model="formResident.is_active" class="sr-only peer">
                    <div class="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                </label>
            </div>

            <button @click="submitResident" class="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 hover:shadow-lg transition-all active:scale-95 text-sm">Simpan Data</button>
        </div>
    </div>
</div>

<div v-if="showSaldoModal" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
  <div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative">
    <button @click="showSaldoModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90">
      <X :size="20"/>
    </button>
    <h3 class="text-xl font-bold text-slate-800 mb-2 flex items-center gap-2">
      <Scale class="text-slate-800"/> Sesuaikan Saldo
    </h3>
    <p class="text-xs text-slate-500 mb-4">Penyesuaian saldo akhir untuk kategori <b>{{ activeCategory.toUpperCase() }}</b>. Angka ini ditambahkan ke total akhir tanpa tercatat di pemasukan bulanan.</p>
    <div class="space-y-4">
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Penyesuaian (Rp)</label>
        <input v-model="formSaldo.amount" type="number" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" placeholder="Bisa minus, misal: -50000">
        <p class="text-[10px] text-slate-400 mt-1 ml-1">Gunakan tanda minus (-) untuk mengurangi saldo.</p>
      </div>
      <button @click="submitSaldo" class="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 hover:shadow-lg transition-all active:scale-95 text-sm">
        Simpan Saldo
      </button>
    </div>
  </div>
</div>

            <div v-if="showIncomeModal" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
  <div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative">
    
    <button @click="showIncomeModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90">
      <X :size="20"/>
    </button>
    
    <h3 class="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
      <TrendingUp class="text-blue-500"/> {{ isIncomeEditing ? 'Edit Pemasukan' : 'Catat Pemasukan' }}
    </h3>
    
    <div class="space-y-4">
      <!-- Input Keterangan -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Keterangan</label>
        <input v-model="formIncome.description" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" placeholder="Contoh: Donasi">
      </div>
      
      <!-- Input Jumlah -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Jumlah (Rp)</label>
        <input v-model="formIncome.amount" type="number" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" placeholder="500000">
      </div>
      
      <!-- Input Tanggal -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Tanggal</label>
        <input v-model="formIncome.date" type="date" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800">
      </div>

      <!-- TAMBAHAN: Dropdown Kategori -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Kategori</label>
        <select v-model="formIncome.category" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800 cursor-pointer">
          <option value="air">Air</option>
          <option value="sampah">Sampah</option>
          <option value="kas">Kas</option>
        </select>
      </div>

      <!-- Tombol Simpan -->
      <button @click="submitIncome" class="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 hover:shadow-lg transition-all active:scale-95 text-sm">
        Simpan Pemasukan
      </button>
    </div>

  </div>
</div>
           <div v-if="showExpenseModal" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
  <div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative">
    <button @click="showExpenseModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90">
      <X :size="20"/>
    </button>
    <h3 class="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
      <TrendingDown class="text-red-500"/> {{ isExpenseEditing ? 'Edit Pengeluaran' : 'Catat Pengeluaran' }}
    </h3>
    <div class="space-y-4">
      <!-- Input Keterangan -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Keterangan</label>
        <input 
          v-model="formExpense.description" 
          class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" 
          placeholder="Contoh: Beli Kaporit"
        />
      </div>
      
      <!-- Input Jumlah -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Jumlah (Rp)</label>
        <input 
          v-model="formExpense.amount" 
          type="number" 
          class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800" 
          placeholder="150000"
        />
      </div>
      
      <!-- Input Tanggal -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Tanggal</label>
        <input 
          v-model="formExpense.date" 
          type="date" 
          class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800"
        />
      </div>

      <!-- Dropdown Kategori -->
      <div>
        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Kategori</label>
        <select 
          v-model="formExpense.category" 
          class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 transition font-bold text-sm text-slate-800"
        >
          <option value="air">Air</option>
          <option value="sampah">Sampah</option>
          <option value="kas">Kas</option>
        </select>
      </div>

      <!-- Tombol Submit -->
      <button 
        @click="submitExpense" 
        class="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 hover:shadow-lg transition-all active:scale-95 text-sm"
      >
        Simpan Pengeluaran
      </button>
    </div>
  </div>
</div>
            <div v-if="showAdminModal" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm"><div class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200 relative max-h-[90vh] overflow-y-auto"><button @click="showAdminModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90"><X :size="20"/></button><h3 class="text-xl font-bold text-slate-800 mb-4">{{ isAdminEditing ? 'Edit Admin' : 'Tambah Admin' }}</h3><div class="space-y-3"><div><label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Nama</label><input v-model="formAdmin.name" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm" placeholder="Nama Admin"></div><div><label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Email</label><input v-model="formAdmin.email" type="email" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm" placeholder="email@contoh.com"></div><div class="border-t border-slate-100 pt-2 mt-2"><p class="text-[10px] text-orange-500 mb-2 italic" v-if="isAdminEditing">*Kosongkan jika tidak ingin ganti password.</p><div><label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Password</label><input v-model="formAdmin.password" type="password" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm" placeholder="******"></div><div class="mt-3"><label class="text-[10px] font-bold text-slate-500 uppercase ml-1">Konfirmasi Password</label><input v-model="formAdmin.password_confirmation" type="password" class="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 font-bold text-sm" placeholder="******"></div></div><button @click="submitAdmin" class="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 hover:shadow-lg transition-all active:scale-95 text-sm mt-2">{{ isAdminEditing ? 'Simpan Perubahan' : 'Tambah Admin' }}</button></div></div></div>
            
            <div v-if="showPaymentModal && selectedResident" class="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm print:bg-white print:p-0 print:absolute print:inset-0">
                
                <div class="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 relative overflow-hidden print:shadow-none print:w-full print:max-w-none print:rounded-none">
                    <button @click="showPaymentModal=false" class="absolute top-4 right-4 z-[70] p-2 bg-gray-100 rounded-full text-slate-500 hover:bg-gray-200 hover:text-red-600 border border-gray-200 transition-all shadow-sm active:scale-90 "><X :size="20"/></button>
                    
                    <div class="flex items-center gap-4 mb-4 border-b border-slate-100 pb-4">
                        <div class="h-14 w-14 bg-gradient-to-tr from-blue-600 to-indigo-500 rounded-2xl flex items-center justify-center shadow-lg text-white font-bold text-xl">{{ selectedResident.blok }}</div>
                        <div><h3 class="text-xl font-bold text-slate-800 leading-tight">{{ selectedResident.nama }}</h3><p class="text-slate-500 font-medium text-sm mt-0.5">Rumah No. {{ selectedResident.nomor }}</p></div>
                    </div>

                    <div class="mb-4 ">
                        <label class="text-[10px] font-bold text-slate-500 uppercase ml-1 mb-1 block">Tahun Pembayaran</label>
                        <div class="flex gap-2 overflow-x-auto pb-2">
                            <button v-for="y in availableYears" :key="y" @click="paymentYear = y" :class="['px-4 py-2 rounded-xl text-sm font-bold border transition', paymentYear === y ? 'bg-slate-800 text-white border-slate-800 shadow-md' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50']">{{ y }}</button>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 relative z-10 max-h-[320px] overflow-y-auto pr-2 custom-scrollbar p-1">
                        <div v-for="(m, index) in MONTHS" :key="m.key" class="relative group">
                            
                            <button 
                                @click="showAmountOptions === m.key ? showAmountOptions = null : showAmountOptions = m.key" 
                                class="w-full text-left p-3 rounded-xl border-2 transition-all duration-200 flex flex-col justify-between h-20 relative overflow-visible" 
                                :class="[getPaymentAmount(selectedResident, m.key, paymentYear) ? 'bg-emerald-50 border-emerald-500 shadow-sm' : 'bg-white border-slate-200 border-dashed hover:border-blue-400 hover:bg-blue-50']"
                            >
                                <div class="flex justify-between items-start z-10 relative">
                                    <span class="text-[10px] font-bold uppercase tracking-wider" :class="getPaymentAmount(selectedResident, m.key, paymentYear) ? 'text-emerald-700' : 'text-slate-400'">{{ m.label }}</span>
                                    <component :is="getPaymentAmount(selectedResident, m.key, paymentYear) ? CheckCircle2 : Circle" :size="16" :class="getPaymentAmount(selectedResident, m.key, paymentYear) ? 'text-emerald-600' : 'text-slate-300'"/>
                                </div>
                              <div class="z-10 relative mt-auto">
    <template v-if="getPaymentAmount(selectedResident, m.key, paymentYear)">
        <p class="text-lg font-bold text-emerald-700">
            {{ ((getPaymentAmount(selectedResident, m.key, paymentYear)) / 1000) }}k
        </p>
        
  <div v-if="isNewTarifPeriod(m.key, paymentYear)" class="flex flex-wrap gap-1 mt-0.5">
  <!-- Label AIR (selalu tampil) -->
  <!-- <span class="px-1 bg-emerald-100 text-[7px] rounded text-emerald-700 font-extrabold">AIR</span> -->
<!-- ✅ Gunakan computed atau method -->
<span v-if="getPaymentDetail(getPaymentAmount(selectedResident, m.key, paymentYear), MONTH_KEYS.indexOf(m.key), paymentYear).air > 0" 
      class="px-1 bg-emerald-100 text-[7px] rounded text-emerald-700 font-extrabold">AIR</span>
  <!-- Label KAS -->
<span v-if="[100000, 70000, 30000, 50000, 50002].includes(getPaymentAmount(selectedResident, m.key, paymentYear))" 
      class="px-1 bg-blue-100 text-[7px] rounded text-blue-700 font-extrabold">KAS</span>

 <!-- Label SAMPAH -->
<span v-if="[100000, 30000, 30001, 10000, 50000, 50002].includes(getPaymentAmount(selectedResident, m.key, paymentYear))" 
      class="px-1 bg-orange-100 text-[7px] rounded text-orange-700 font-extrabold">SMPH</span>

  <!-- Label AIR SAJA (untuk paket 50001 hack) -->
  <span v-if="getPaymentAmount(selectedResident, m.key, paymentYear) === 50001" 
        class="px-1 bg-green-100 text-[7px] rounded text-green-700 font-extrabold">
    AIR SAJA
  </span>
</div>
    </template>
    
    <div v-else class="flex flex-col">
        <p class="text-[10px] font-medium text-slate-400">Tagihan</p>
        
        <p v-if="isNewTarifPeriod(m.key, paymentYear)" class="text-[9px] font-bold text-blue-500 leading-tight">
            Pilih Paket
        </p>
        
        <p v-else class="text-[9px] font-bold text-slate-500">
            {{ (selectedResident.tarif || 20000) / 1000 }}k
        </p>
    </div>
</div>
                            </button>

                            <div v-if="showAmountOptions === m.key && currentUser" 
                                class="absolute left-1/2 -translate-x-1/2 w-40 bg-white rounded-xl shadow-xl border border-slate-200 p-2.5 z-[100] flex flex-col gap-2 animate-in zoom-in-95"
                                :class="[
                                    index < 6 ? 'top-full mt-2 origin-top' : 'bottom-full mb-2 origin-bottom'
                                ]"
                            >
                                <button v-if="getPaymentAmount(selectedResident, m.key, paymentYear)" @click="togglePayment(m.key); showAmountOptions=null" class="w-full py-2 bg-red-50 text-red-600 text-xs font-bold rounded-lg hover:bg-red-100 flex items-center justify-center gap-2">
                                    <Trash2 :size="14"/> Batalkan
                                </button>

                                <div v-else class="flex flex-col gap-2">
    <p class="text-[10px] text-center text-slate-400 font-bold uppercase tracking-wider">
        Pilih Paket {{ isNewTarifPeriod(m.key, paymentYear) ? '2026' : '' }}
    </p>

<!-- PAKET LENGKAP (April 2026+) -->
<template v-if="isNewTarifPeriod(m.key, paymentYear)">
    <!-- Paket Premium -->
    <button @click="togglePayment(m.key, 100000); showAmountOptions=null" 
            class="w-full py-2 bg-emerald-50 text-emerald-700 text-[11px] font-bold rounded-lg hover:bg-emerald-100 border border-emerald-100 leading-tight">
        Rp 100.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Air+Sampah+Kas)</span>
    </button>

    <!-- Air + Kas -->
    <button @click="togglePayment(m.key, 70000); showAmountOptions=null" 
            class="w-full py-2 bg-blue-50 text-blue-700 text-[11px] font-bold rounded-lg hover:bg-blue-100 border border-blue-100 leading-tight">
        Rp 70.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Air+Kas)</span>
    </button>
    
    <!-- Sampah + Kas (PAKET BARU) -->
    <button @click="togglePayment(m.key, 30000); showAmountOptions=null" 
            class="w-full py-2 bg-orange-50 text-orange-700 text-[11px] font-bold rounded-lg hover:bg-orange-100 border border-orange-100 leading-tight">
        Rp 30.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Sampah+Kas)</span>
    </button>

     <!-- Sampah + Kas (PAKET BARU) -->
    <button @click="togglePayment(m.key, 50002); showAmountOptions=null" 
            class="w-full py-2 bg-orange-50 text-orange-700 text-[11px] font-bold rounded-lg hover:bg-orange-100 border border-orange-100 leading-tight">
        Rp 50.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Sampah+Kas)</span>
    </button>

    <!-- Sampah Only (PAKET BARU) -->
    <button @click="togglePayment(m.key, 30001); showAmountOptions=null" 
            class="w-full py-2 bg-red-50 text-red-700 text-[11px] font-bold rounded-lg hover:bg-red-100 border border-red-100 leading-tight">
        Rp 30.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Sampah)</span>
    </button>

    <!-- Paket Hemat -->
    <button @click="togglePayment(m.key, 50000); showAmountOptions=null" 
            class="w-full py-2 bg-slate-50 text-slate-600 text-[11px] font-bold rounded-lg hover:bg-slate-100 border border-slate-200 leading-tight">
        Rp 50.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Air+Sampah+Kas)</span>
    </button>

    <!-- Sampah Mini (PAKET BARU) -->
    <button @click="togglePayment(m.key, 10000); showAmountOptions=null" 
            class="w-full py-2 bg-yellow-50 text-yellow-700 text-[11px] font-bold rounded-lg hover:bg-yellow-100 border border-yellow-100 leading-tight">
        Rp 10.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Sampah Mini)</span>
    </button>

    <!-- Air Only 50rb Hack -->
    <button @click="togglePayment(m.key, 50001); showAmountOptions=null" 
            class="w-full py-2 bg-blue-50 text-blue-700 text-[11px] font-bold rounded-lg hover:bg-blue-100 border border-blue-100 leading-tight">
        Rp 50.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Air Saja)</span>
    </button>

    <!-- Air Only 20rb -->
    <button @click="togglePayment(m.key, 20000); showAmountOptions=null" 
            class="w-full py-2 bg-green-50 text-green-700 text-[11px] font-bold rounded-lg hover:bg-green-100 border border-green-100 leading-tight">
        Rp 20.000<br/>
        <span class="text-[8px] font-medium opacity-70">(Air Saja)</span>
    </button>
</template>

    <template v-else>
        <button @click="togglePayment(m.key, parseInt(selectedResident.tarif || 20000)); showAmountOptions=null" 
                class="w-full py-2 bg-blue-50 text-blue-700 text-xs font-bold rounded-lg hover:bg-blue-100 border border-blue-100">
            {{ formatRupiah(selectedResident.tarif || 20000) }}
        </button>
        <button @click="togglePayment(m.key, (selectedResident.tarif == 50000 ? 20000 : 50000)); showAmountOptions=null" 
                class="w-full py-2 bg-slate-50 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-100 border border-slate-200">
            {{ formatRupiah(selectedResident.tarif == 50000 ? 20000 : 50000) }}
        </button>
    </template>
</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex gap-3 relative z-10 border-t border-slate-100 pt-4 ">
                        <button @click="showQrisModal = true" class="flex-1 bg-blue-600 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-blue-700 shadow-md transition-all active:scale-95"><QrCode :size="18"/> Bayar Pakai QRIS</button>
                        <button @click="printCard" class="flex-1 bg-slate-900 text-white px-4 py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 hover:bg-slate-700 shadow-md transition-all active:scale-95"><Printer :size="18"/> Cetak Kartu</button>
                    </div>
                </div>
            </div>

         <!-- Bagian Modal QRIS yang sudah diperbaiki -->
<div 
    v-if="showQrisModal" 
    class="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md transition-all " 
    @click="showQrisModal = false"
>
    <div 
        class="bg-white rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 relative flex flex-col items-center" 
        @click.stop
    >
        <button 
            @click="showQrisModal = false" 
            class="absolute top-3 right-3 z-50 p-2 bg-slate-100 rounded-full text-slate-500 hover:bg-red-100 hover:text-red-500 transition-all"
        >
            <X :size="20"/>
        </button>
        
        <h3 class="text-xl font-bold text-slate-800 mb-2">Scan QRIS</h3>
        <p class="text-xs text-slate-500 mb-4 text-center">
            Scan kode di bawah menggunakan e-wallet (GoPay, Dana, OVO, ShopeePay) atau m-banking.
        </p>
        
        <!-- Bagian Gambar QRIS yang diperbaiki -->
        <div class="bg-white p-3 rounded-xl border-2 border-slate-900 mb-4 w-full max-w-[240px] mx-auto">
            <img 
                src="/images/Qrisnew.png" 
                alt="QRIS Code" 
                class="w-full h-auto object-contain"
            >
        </div>
        
        <p class="text-xs font-bold text-slate-800 bg-yellow-100 px-3 py-1.5 rounded-lg border border-yellow-200">
            Wajib konfirmasi ke Admin setelah transfer!
        </p>
    </div>
</div>

        </main>
    </div>

  <div id="print-area" v-if="selectedResident" 
     class="print:absolute print:top-0 print:left-0 print:w-full print:bg-white p-8 text-black"
     style="display: none;">
    <div class="text-center border-b-2 border-black pb-4 mb-6">
        <h1 class="text-2xl font-bold uppercase">Kartu Iuran Air & Lingkungan</h1>
        <p class="text-sm">Perumahan Nuansa - Tahun {{ paymentYear }}</p>
    </div>

    <div class="grid grid-cols-2 gap-4 mb-6 text-sm">
        <div>
            <p><strong>Nama Warga:</strong> {{ selectedResident.nama }}</p>
            <p><strong>Alamat:</strong> Blok {{ selectedResident.blok }} No. {{ selectedResident.nomor }}</p>
        </div>
        <div class="text-right">
            <p><strong>Tanggal Cetak:</strong> {{ new Date().toLocaleDateString('id-ID') }}</p>
        </div>
    </div>

    <table class="w-full border-collapse border border-black">
        <thead>
            <tr class="bg-gray-100">
                <th class="border border-black p-2 text-left">Bulan</th>
                <th class="border border-black p-2 text-right">Nominal</th>
                <th class="border border-black p-2 text-center">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="m in MONTHS" :key="m.key">
                <td class="border border-black p-2 font-medium">{{ m.label }}</td>
                <td class="border border-black p-2 text-right">
                    {{ getPaymentAmount(selectedResident, m.key, paymentYear) ? formatRupiah(getPaymentAmount(selectedResident, m.key, paymentYear)) : '-' }}
                </td>
                <td class="border border-black p-2 text-center text-xs">
    <template v-if="getPaymentAmount(selectedResident, m.key, paymentYear)">
        <span v-if="!isNewTarifPeriod(m.key, paymentYear)">LUNAS (Tarif Lama)</span>
        <span v-else-if="getPaymentAmount(selectedResident, m.key, paymentYear) === 100000">LUNAS (Air+Kas+Sampah)</span>
        <span v-else-if="getPaymentAmount(selectedResident, m.key, paymentYear) === 70000">LUNAS (Air+Kas)</span>
        <span v-else-if="getPaymentAmount(selectedResident, m.key, paymentYear) === 50000">LUNAS (Air+Kas+Sampah)</span>
        <span v-else-if="getPaymentAmount(selectedResident, m.key, paymentYear) === 50001">LUNAS (Air Saja)</span>
        <span v-else>LUNAS</span>
    </template>
</td>
            </tr>
        </tbody>
    </table>
</div>
    <!-- MODAL PREVIEW SURAT (Agar bisa lihat dulu sebelum print) -->
<div v-if="showLetterModal" class="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm print:p-0 print:bg-white print:absolute print:inset-0">
    
    <!-- Kotak Preview & Button Cetak -->
    <div class="bg-white w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden flex flex-col h-[90vh] print:shadow-none print:h-auto print:w-full print:max-w-none print:rounded-none animate-in zoom-in-95">
        
        <!-- Toolbar Print -->
        <div class="bg-slate-800 text-white p-4 flex justify-between items-center ">
            <h3 class="font-bold">Preview Surat Tagihan</h3>
            <div class="flex gap-2">
                <button @click="showLetterModal = false" class="px-4 py-2 bg-slate-700 rounded hover:bg-slate-600 text-sm">Tutup</button>
                <button @click="printLetter" class="px-4 py-2 bg-blue-600 rounded hover:bg-blue-500 text-sm font-bold flex items-center gap-2">
                    <Printer :size="16"/> Cetak / Save PDF
                </button>
            </div>
        </div>

        <!-- AREA SURAT (Yang akan diprint) -->
        <div id="letter-print-area" class="flex-1 overflow-y-auto bg-white p-8 md:p-12 print:p-0 text-slate-800">
            
            <!-- Kop Surat -->
            <div class="border-b-4 border-slate-800 pb-6 mb-8 flex justify-between items-end">
                <div>
                    <h1 class="text-3xl font-extrabold uppercase tracking-widest text-slate-900">Surat Tagihan</h1>
                    <p class="text-sm font-bold text-slate-500 mt-1">NUANSA MANISI REGENCY</p>
                </div>
                <div class="text-right">
                    <p class="text-xs font-bold text-slate-400">Tanggal Cetak</p>
                    <p class="font-bold">{{ new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' }) }}</p>
                </div>
            </div>

            <!-- Kepada Yth -->
            <div class="mb-8">
                <p class="font-bold text-sm mb-1">Kepada Yth,</p>
                <p class="font-bold text-lg mb-1">{{ selectedResidentForLetter?.nama }}</p>
                <p class="text-sm">Bpk/Ibu Warga Blok {{ selectedResidentForLetter?.blok }} / No. {{ selectedResidentForLetter?.nomor }}</p>
            </div>

            <!-- Isi Surat -->
            <div class="mb-8">
                <p class="text-sm mb-4">Dengan hormat,<br>Kami informasikan bahwa ada tagihan iuran air yang belum dibayarkan. Berikut rinciannya:</p>

                <table class="w-full text-left border-collapse border border-slate-300 text-sm">
                    <thead>
                        <tr class="bg-slate-100">
                            <th class="border border-slate-300 p-3 font-bold">Bulan</th>
                            <th class="border border-slate-300 p-3 font-bold text-right">Jumlah Tagihan</th>
                            <th class="border border-slate-300 p-3 font-bold text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Loop Bulan (Januari - Sekarang) -->
                        <tr v-for="(m, index) in MONTHS.slice(0, new Date().getMonth() + 1)" :key="m.key">
                            <td class="border border-slate-300 p-3 font-medium">{{ m.label }} {{ selectedFinancialYear }}</td>
                            <td class="border border-slate-300 p-3 text-right font-mono">{{ formatRupiah(selectedResidentForLetter?.tarif) }}</td>
                            <td class="border border-slate-300 p-3 text-center">
                                <span v-if="getPaymentAmount(selectedResidentForLetter, m.key, selectedFinancialYear)" class="text-green-600 font-bold">LUNAS</span>
                                <span v-else class="text-red-600 font-bold">MENUNGGAK</span>
                            </td>
                        </tr>
                        <!-- Total -->
                        <tr class="bg-slate-50 font-bold">
                            <td class="border border-slate-300 p-3 text-right">TOTAL TAGIHAN:</td>
                            <td class="border border-slate-300 p-3 text-right text-red-600 text-lg">{{ formatRupiah(getResidentTotalDebt) }}</td>
                            <td class="border border-slate-300 p-3"></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Penutup -->
            <div class="mb-12">
                <p class="text-sm">Mohon segera melakukan pembayaran agar tidak terkena denda. Pembayaran dapat dilakukan melalui transfer ke rekening QRIS yang tertera di aplikasi atau langsung ke bendahara.</p>
            </div>

            <!-- Tanda Tangan -->
            <div class="flex justify-end mt-12">
                <div class="text-center w-48">
                    <p class="text-sm mb-8">Hormat Kami,<br>Panitia Pengelola</p>
                    <p class="font-bold border-t border-slate-800 pt-2">{{ currentUser?.name || 'Admin' }}</p>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center mt-12 pt-6 border-t border-slate-200">
                <p class="text-[10px] text-slate-400">Dicetak secara otomatis oleh Sistem Air Nuansa.</p>
            </div>
        </div>
    </div>
</div>
    <!-- BOTTOM NAV - Hanya tampil di mobile -->
<div class="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white border-t border-slate-200 shadow-lg">
    <div class="flex items-center justify-around px-2 py-2">
        <button 
            v-for="tab in visibleTabs" 
            :key="tab.id" 
            @click="activeTab = tab.id"
            :class="[
                'flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all flex-1',
                activeTab === tab.id 
                    ? 'text-blue-600' 
                    : 'text-slate-400 hover:text-slate-600'
            ]"
        >
            <component 
                :is="tab.icon" 
                :size="22" 
                :class="{ 'stroke-[2.5px]': activeTab === tab.id }"
            />
            <span class="text-[10px] font-bold">{{ tab.label }}</span>
        </button>
    </div>
</div>

  </div>
</template>

<style>

/* --- Styling Biasa (Scrollbar) --- */
.custom-scrollbar::-webkit-scrollbar { width: 4px; }
.custom-scrollbar::-webkit-scrollbar-track { background: #f1f5f9; }
.custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
.custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

/* Override visibility pada mobile */
@media screen and (max-width: 768px) {
    nav, main {
        display: block !important;
        visibility: visible !important;
        height: auto !important;
    }
}

/* ✅ FIX CSS - ganti blok @media print */
@media print {
    body * { display: none !important; }

    /* Mode cetak kartu */
    body.print-card #print-area,
    body.print-card #print-area * {
        display: revert !important;
    }
    body.print-card #print-area table  { display: table !important; }
    body.print-card #print-area thead  { display: table-header-group !important; }
    body.print-card #print-area tbody  { display: table-row-group !important; }
    body.print-card #print-area tr     { display: table-row !important; }
    body.print-card #print-area td,
    body.print-card #print-area th     { display: table-cell !important; }
    body.print-card #print-area {
        position: fixed !important;
        top: 0 !important; left: 0 !important;
        width: 100vw !important;
        background: white !important;
        z-index: 99999 !important;
        padding: 2rem !important;
    }

    /* Mode cetak surat */
    body.print-letter #letter-print-area,
    body.print-letter #letter-print-area * {
        display: revert !important;
    }
    body.print-letter #letter-print-area table  { display: table !important; }
    body.print-letter #letter-print-area thead  { display: table-header-group !important; }
    body.print-letter #letter-print-area tbody  { display: table-row-group !important; }
    body.print-letter #letter-print-area tr     { display: table-row !important; }
    body.print-letter #letter-print-area td,
    body.print-letter #letter-print-area th     { display: table-cell !important; }
    body.print-letter #letter-print-area {
        position: fixed !important;
        top: 0 !important; left: 0 !important;
        width: 100vw !important;
        background: white !important;
        z-index: 99999 !important;
        padding: 2rem !important;
    }

    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
}

.tunggakan-cell {
    padding: 0 1rem;
    font-weight: 700;
    color: #dc2626;
    text-align: center;
    white-space: nowrap;
    font-size: 0.875rem;
}

.marquee {
    overflow: hidden;
    white-space: nowrap;
    animation: marqueeAnim 15s linear infinite;
}
@keyframes marqueeAnim {
    0%   { transform: translateX(100%); }
    100% { transform: translateX(-100%); }
}
</style>